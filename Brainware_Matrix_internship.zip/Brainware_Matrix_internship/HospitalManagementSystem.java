
import java.util.*;

// Patient class
class Patient {
    int id;
    String name;
    int age;
    String gender;
    String contact;

    public Patient(int id, String name, int age, String gender, String contact) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.contact = contact;
    }

    public String toString() {
        return id + ". " + name + ", Age: " + age + ", Gender: " + gender + ", Contact: " + contact;
    }
}

// Appointment class
class Appointment {
    int appointmentId;
    int patientId;
    String doctorName;
    String date;
    String time;

    public Appointment(int appointmentId, int patientId, String doctorName, String date, String time) {
        this.appointmentId = appointmentId;
        this.patientId = patientId;
        this.doctorName = doctorName;
        this.date = date;
        this.time = time;
    }

    public String toString() {
        return "Appointment ID: " + appointmentId + ", Patient ID: " + patientId + ", Doctor: " + doctorName + ", Date: " + date + ", Time: " + time;
    }
}

// Health Record class
class HealthRecord {
    int patientId;
    String diagnosis;
    String prescription;
    String testResults;

    public HealthRecord(int patientId, String diagnosis, String prescription, String testResults) {
        this.patientId = patientId;
        this.diagnosis = diagnosis;
        this.prescription = prescription;
        this.testResults = testResults;
    }

    public String toString() {
        return "Patient ID: " + patientId + ", Diagnosis: " + diagnosis + ", Prescription: " + prescription + ", Test Results: " + testResults;
    }
}

// Billing class
class Bill {
    int billId;
    int patientId;
    double amount;
    boolean isPaid;

    public Bill(int billId, int patientId, double amount, boolean isPaid) {
        this.billId = billId;
        this.patientId = patientId;
        this.amount = amount;
        this.isPaid = isPaid;
    }

    public String toString() {
        return "Bill ID: " + billId + ", Patient ID: " + patientId + ", Amount: " + amount + ", Status: " + (isPaid ? "Paid" : "Unpaid");
    }
}

// Inventory Item class
class InventoryItem {
    int itemId;
    String itemName;
    int quantity;
    String expiryDate;

    public InventoryItem(int itemId, String itemName, int quantity, String expiryDate) {
        this.itemId = itemId;
        this.itemName = itemName;
        this.quantity = quantity;
        this.expiryDate = expiryDate;
    }

    public String toString() {
        return "Item ID: " + itemId + ", Name: " + itemName + ", Quantity: " + quantity + ", Expiry: " + expiryDate;
    }
}

// Staff class
class Staff {
    int staffId;
    String name;
    String role;
    String department;

    public Staff(int staffId, String name, String role, String department) {
        this.staffId = staffId;
        this.name = name;
        this.role = role;
        this.department = department;
    }

    public String toString() {
        return "Staff ID: " + staffId + ", Name: " + name + ", Role: " + role + ", Department: " + department;
    }
}

public class HospitalManagementSystem {
    static List<Patient> patients = new ArrayList<>();
    static List<Appointment> appointments = new ArrayList<>();
    static List<HealthRecord> healthRecords = new ArrayList<>();
    static List<Bill> bills = new ArrayList<>();
    static List<InventoryItem> inventory = new ArrayList<>();
    static List<Staff> staffList = new ArrayList<>();

    static int patientIdCounter = 1;
    static int appointmentIdCounter = 1;
    static int billIdCounter = 1;
    static int itemIdCounter = 1;
    static int staffIdCounter = 1;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n=== Hospital Management System ===");
            System.out.println("1. Register Patient");
            System.out.println("2. View Patients");
            System.out.println("3. Schedule Appointment");
            System.out.println("4. View Appointments");
            System.out.println("5. Add Health Record");
            System.out.println("6. View Health Records");
            System.out.println("7. Generate Bill");
            System.out.println("8. View Bills");
            System.out.println("9. Manage Inventory");
            System.out.println("10. View Inventory");
            System.out.println("11. Add Staff");
            System.out.println("12. View Staff");
            System.out.println("13. Exit");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> registerPatient(sc);
                case 2 -> viewPatients();
                case 3 -> scheduleAppointment(sc);
                case 4 -> viewAppointments();
                case 5 -> addHealthRecord(sc);
                case 6 -> viewHealthRecords();
                case 7 -> generateBill(sc);
                case 8 -> viewBills();
                case 9 -> manageInventory(sc);
                case 10 -> viewInventory();
                case 11 -> addStaff(sc);
                case 12 -> viewStaff();
                case 13 -> {
                    System.out.println("Exiting... Thank you!");
                    return;
                }
                default -> System.out.println("Invalid option. Try again.");
            }
        }
    }

    public static void registerPatient(Scanner sc) {
        System.out.print("Enter name: ");
        String name = sc.nextLine();
        System.out.print("Enter age: ");
        int age = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter gender: ");
        String gender = sc.nextLine();
        System.out.print("Enter contact: ");
        String contact = sc.nextLine();

        Patient newPatient = new Patient(patientIdCounter++, name, age, gender, contact);
        patients.add(newPatient);
        System.out.println("Patient registered successfully!");
    }

    public static void viewPatients() {
        patients.forEach(System.out::println);
    }

    public static void scheduleAppointment(Scanner sc) {
        System.out.print("Enter patient ID: ");
        int pid = sc.nextInt(); sc.nextLine();
        System.out.print("Enter doctor name: ");
        String doc = sc.nextLine();
        System.out.print("Enter date (dd-mm-yyyy): ");
        String date = sc.nextLine();
        System.out.print("Enter time (HH:mm): ");
        String time = sc.nextLine();

        appointments.add(new Appointment(appointmentIdCounter++, pid, doc, date, time));
        System.out.println("Appointment scheduled!");
    }

    public static void viewAppointments() {
        appointments.forEach(System.out::println);
    }

    public static void addHealthRecord(Scanner sc) {
        System.out.print("Enter patient ID: ");
        int pid = sc.nextInt(); sc.nextLine();
        System.out.print("Diagnosis: ");
        String diag = sc.nextLine();
        System.out.print("Prescription: ");
        String pres = sc.nextLine();
        System.out.print("Test Results: ");
        String test = sc.nextLine();

        healthRecords.add(new HealthRecord(pid, diag, pres, test));
        System.out.println("Health record added!");
    }

    public static void viewHealthRecords() {
        healthRecords.forEach(System.out::println);
    }

    public static void generateBill(Scanner sc) {
        System.out.print("Enter patient ID: ");
        int pid = sc.nextInt();
        System.out.print("Enter amount: ");
        double amt = sc.nextDouble();
        System.out.print("Is paid? (true/false): ");
        boolean paid = sc.nextBoolean();

        bills.add(new Bill(billIdCounter++, pid, amt, paid));
        System.out.println("Bill generated!");
    }

    public static void viewBills() {
        bills.forEach(System.out::println);
    }

    public static void manageInventory(Scanner sc) {
        System.out.print("Item name: ");
        String name = sc.nextLine();
        System.out.print("Quantity: ");
        int qty = sc.nextInt(); sc.nextLine();
        System.out.print("Expiry Date: ");
        String expiry = sc.nextLine();

        inventory.add(new InventoryItem(itemIdCounter++, name, qty, expiry));
        System.out.println("Item added to inventory!");
    }

    public static void viewInventory() {
        inventory.forEach(System.out::println);
    }

    public static void addStaff(Scanner sc) {
        System.out.print("Name: ");
        String name = sc.nextLine();
        System.out.print("Role: ");
        String role = sc.nextLine();
        System.out.print("Department: ");
        String dept = sc.nextLine();

        staffList.add(new Staff(staffIdCounter++, name, role, dept));
        System.out.println("Staff added!");
    }

    public static void viewStaff() {
        staffList.forEach(System.out::println);
    }
}

